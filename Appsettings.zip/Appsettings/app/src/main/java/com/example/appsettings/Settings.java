package com.example.appsettings;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class Settings extends AppCompatActivity {

    Button button1;
    Spinner spinner;
    EditText input;
    String text;
    public static final String SHARED_PREFS ="mine";
    ArrayAdapter<CharSequence> adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);




        spinner = findViewById(R.id.spinner);
        button1 = findViewById(R.id.button1);
        input = findViewById(R.id.input);



        SharedPreferences sp = getSharedPreferences(SHARED_PREFS,Context.MODE_PRIVATE);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if(position==0){
                    SharedPreferences.Editor editor = sp.edit();
                    editor.putInt("color", getResources().getColor(R.color.red));
                    editor.commit();
                } else if (position==1) {
                    SharedPreferences.Editor editor = sp.edit();
                    editor.putInt("color",getResources().getColor(R.color.blue));
                    editor.commit();
                }else {
                    SharedPreferences.Editor editor = sp.edit();
                    editor.putInt("color",getResources().getColor(R.color.green));
                    editor.commit();
                }
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(Settings.this, MainActivity.class);
                text = input.getText().toString();
                SharedPreferences.Editor editor = sp.edit();
                editor.putString("text",text);
                editor.commit();
                startActivity(intent);
            }
        });

    }
}